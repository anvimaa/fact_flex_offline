import{l as o,k as r}from"../chunks/TGl8V12P.js";export{o as load_css,r as start};
