import"./CWj6FrbW.js";import"./BNb8TLk_.js";import{k as l,f as n,a as d}from"./CoUivBMM.js";import{s as i}from"./DzKZcwai.js";import{l as m,s as c}from"./BeM9_8ch.js";import{I as f}from"./DC9vk8jV.js";function k(s,a){const o=m(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"}],["path",{d:"M20 3v4"}],["path",{d:"M22 5h-4"}],["path",{d:"M4 17v2"}],["path",{d:"M5 18H3"}]];f(s,c({name:"sparkles"},()=>o,{get iconNode(){return r},children:(e,$)=>{var t=l(),p=n(t);i(p,a,"default",{},null),d(e,t)},$$slots:{default:!0}}))}export{k as S};
