import"./CWj6FrbW.js";import"./BNb8TLk_.js";import{k as d,f as n,a as i}from"./CoUivBMM.js";import{s as h}from"./DzKZcwai.js";import{l,s as m}from"./BeM9_8ch.js";import{I as c}from"./DC9vk8jV.js";function y(o,a){const s=l(a,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=[["path",{d:"M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"}],["path",{d:"M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"}],["path",{d:"M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"}],["path",{d:"M10 6h4"}],["path",{d:"M10 10h4"}],["path",{d:"M10 14h4"}],["path",{d:"M10 18h4"}]];c(o,m({name:"building-2"},()=>s,{get iconNode(){return r},children:(e,f)=>{var t=d(),p=n(t);h(p,a,"default",{},null),i(e,t)},$$slots:{default:!0}}))}export{y as B};
